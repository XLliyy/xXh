package org.cloudburstmc.proxypass.auth;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.Value;
import lombok.extern.log4j.Log4j2;
import net.raphimc.minecraftauth.MinecraftAuth;
import net.raphimc.minecraftauth.bedrock.BedrockAuthManager;
import net.raphimc.minecraftauth.bedrock.model.MinecraftCertificateChain;
import net.raphimc.minecraftauth.msa.model.MsaDeviceCode;
import net.raphimc.minecraftauth.msa.service.impl.DeviceCodeMsaAuthService;
import org.cloudburstmc.protocol.bedrock.util.ChainValidationResult;
import org.cloudburstmc.protocol.bedrock.util.EncryptionUtils;
import org.cloudburstmc.proxypass.network.bedrock.util.ForgeryUtils;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.security.KeyPair;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Microsoft (Xbox Live) authentication for the downstream connection.
 *
 * <p>Upstream ProxyPass forges a self-signed identity for the backend, which is why the
 * backend has to run with {@code online-mode=false}. This service instead logs the
 * <em>proxy itself</em> in with a Microsoft account (device-code flow, via
 * <a href="https://github.com/RaphiMC/MinecraftAuth">RaphiMC/MinecraftAuth</a>) and
 * asks Mojang's {@code multiplayer.minecraft.net/authentication} endpoint for a real
 * Xbox-signed certificate chain bound to the proxy's session key pair. The backend
 * can then run with {@code online-mode=true}.</p>
 *
 * <p>One hard limit, by design: the backend sees the <em>proxy operator's</em>
 * Microsoft account (gamertag/XUID), not the upstream player's account. A proxy
 * cannot re-sign another player's Xbox chain with its own key - the Mojang
 * signature would break - so impersonating the upstream player is cryptographically
 * impossible without that player's Microsoft credentials. Upstream players are still
 * validated as usual; only the downstream identity changes.</p>
 *
 * <p>Tokens (including the Microsoft refresh token) are cached in the configured
 * token file. Keep that file secret and never share it: anyone holding it can play
 * as the proxy's Microsoft account until the refresh token is revoked.</p>
 */
@Log4j2
public class MicrosoftAuthService {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path tokenFile;
    private final String gameVersion;
    private BedrockAuthManager authManager;

    public MicrosoftAuthService(Path tokenFile, String gameVersion) {
        this.tokenFile = tokenFile;
        this.gameVersion = gameVersion;
    }

    /**
     * Loads cached tokens if the token file exists.
     *
     * @return {@code true} if a previous login was restored
     */
    public boolean loadCachedTokens() {
        if (!Files.isRegularFile(this.tokenFile)) {
            return false;
        }
        try {
            JsonObject json = JsonParser.parseString(Files.readString(this.tokenFile)).getAsJsonObject();
            this.authManager = BedrockAuthManager.fromJson(MinecraftAuth.createHttpClient("ProxyPass"), this.gameVersion, json);
            this.attachSaveListener();
            log.info("Loaded cached Microsoft login from {}", this.tokenFile);
            return true;
        } catch (Exception failure) {
            log.warn("Cached Microsoft login in {} is unreadable ({}). A fresh login is required.", this.tokenFile, failure.getMessage());
            this.authManager = null;
            return false;
        }
    }

    /**
     * Runs the Microsoft device-code flow on the calling thread (blocks up to 5 minutes).
     * The operator opens the printed URL and enters the printed code in a browser.
     */
    public void loginWithDeviceCode() throws IOException {
        try {
            log.info("Microsoft login required. Open the URL below in a browser and enter the code.");
            Consumer<MsaDeviceCode> showCode = deviceCode -> {
                log.info("Go to {} and enter code {}", deviceCode.getVerificationUri(), deviceCode.getUserCode());
                log.info("Direct link (no code to type): {}", deviceCode.getDirectVerificationUri());
            };
            this.authManager = BedrockAuthManager.create(MinecraftAuth.createHttpClient("ProxyPass"), this.gameVersion)
                    .login(DeviceCodeMsaAuthService::new, showCode);
        } catch (InterruptedException failure) {
            Thread.currentThread().interrupt();
            throw new IOException("Microsoft device-code login was interrupted", failure);
        } catch (Exception failure) {
            throw new IOException("Microsoft device-code login failed: " + failure.getMessage(), failure);
        }
        this.attachSaveListener();
        this.save();
        MinecraftCertificateChain chain = this.authManager.getMinecraftCertificateChain().getUpToDate();
        log.info("Microsoft login succeeded as {} (XUID {})", chain.getIdentityDisplayName(), chain.getIdentityXuid());
    }

    /**
     * Makes sure a login exists: restores cached tokens, or runs the device-code
     * flow when {@code loginOnStartup} allows it.
     */
    public void ensureLoggedIn(boolean loginOnStartup) throws IOException {
        if (this.loadCachedTokens()) {
            return;
        }
        if (!loginOnStartup) {
            throw new IOException("Microsoft auth is enabled but no login is cached in " + this.tokenFile
                    + ". Run: java -jar ProxyPass.jar --microsoft-login");
        }
        this.loginWithDeviceCode();
    }

    public boolean isLoggedIn() {
        return this.authManager != null;
    }

    /**
     * Builds the downstream login for one player session: a fresh Xbox-signed
     * certificate chain for the proxy's Microsoft account, bound to the proxy's
     * session key pair. The chain is validated locally (Mojang root signature)
     * before it is ever sent, so a broken chain fails here instead of at the backend.
     *
     * <p>This only refreshes tokens over the network; it never prompts for a login.
     * If the refresh token is dead, it throws and the operator must re-run
     * {@code --microsoft-login}.</p>
     */
    public DownstreamLogin prepareDownstreamLogin() throws IOException {
        if (this.authManager == null) {
            throw new IOException("Microsoft auth is enabled but nobody is logged in. Run: java -jar ProxyPass.jar --microsoft-login");
        }
        MinecraftCertificateChain chain = this.authManager.getMinecraftCertificateChain().getUpToDate();
        KeyPair sessionKey = this.authManager.getSessionKeyPair();

        String firstToken;
        try {
            firstToken = ForgeryUtils.forgeIdentityToken(sessionKey, readX5u(chain.getMojangJwt()));
        } catch (JoseException failure) {
            throw new IOException("Unable to read the Mojang certificate from the Microsoft login", failure);
        }

        List<String> fullChain = List.of(firstToken, chain.getMojangJwt(), chain.getIdentityJwt());
        ChainValidationResult result;
        try {
            result = EncryptionUtils.validateChain(fullChain);
        } catch (Exception failure) {
            throw new IOException("Refusing to send a downstream login chain that fails local validation: " + failure.getMessage(), failure);
        }
        if (!result.signed()) {
            throw new IOException("Microsoft login chain is not Xbox-signed; refusing to send it downstream");
        }
        ChainValidationResult.IdentityData identity = result.identityClaims().extraData;
        log.debug("Downstream Microsoft identity: {} (XUID {})", identity.displayName, identity.xuid);
        return new DownstreamLogin(fullChain, identity, sessionKey);
    }

    private void attachSaveListener() {
        this.authManager.getChangeListeners().add(() -> {
            try {
                this.save();
            } catch (IOException failure) {
                log.warn("Failed to save Microsoft login tokens: {}", failure.getMessage());
            }
        });
    }

    private synchronized void save() throws IOException {
        if (this.authManager == null) {
            return;
        }
        Files.createDirectories(this.tokenFile.toAbsolutePath().getParent());
        Files.writeString(this.tokenFile, GSON.toJson(BedrockAuthManager.toJson(this.authManager)));
        try {
            Files.setPosixFilePermissions(this.tokenFile, Set.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        } catch (Exception ignored) {
            // Non-POSIX filesystems (e.g. Windows) do not support this; the file is still written.
        }
    }

    private static String readX5u(String jwt) throws JoseException {
        JsonWebSignature signature = new JsonWebSignature();
        signature.setCompactSerialization(jwt);
        return signature.getHeader(HeaderParameterNames.X509_URL);
    }

    /**
     * Everything one downstream login needs: the Xbox-signed chain, the identity
     * the backend will see, and the session key pair the chain (and the downstream
     * encryption handshake) is bound to.
     */
    @Value
    public static class DownstreamLogin {
        List<String> chain;
        ChainValidationResult.IdentityData identity;
        KeyPair sessionKeyPair;
    }
}
