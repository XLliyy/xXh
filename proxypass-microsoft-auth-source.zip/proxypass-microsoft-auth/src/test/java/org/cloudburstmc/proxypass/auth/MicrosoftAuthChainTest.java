package org.cloudburstmc.proxypass.auth;

import org.cloudburstmc.protocol.bedrock.util.TestIdentityData;
import org.cloudburstmc.proxypass.network.bedrock.util.ForgeryUtils;
import org.jose4j.json.JsonUtil;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.NumericDate;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.junit.jupiter.api.Test;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.spec.ECGenParameterSpec;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Offline tests for the Microsoft-auth downstream chain construction.
 *
 * <p>No Microsoft account is needed: the "Mojang" and identity JWTs are synthetic
 * tokens signed by test keys. They are <em>not</em> signed by the real Mojang root
 * key, so {@code EncryptionUtils.validateChain} is intentionally <em>not</em>
 * asserted here - it would reject the synthetic Mojang token. Instead the test
 * replays the same signature walk {@code validateChain} performs (each token
 * verified with the previous token's {@code identityPublicKey}), minus only the
 * Mojang-root equality check. With real tokens from
 * {@code multiplayer.minecraft.net/authentication} that check passes too, which
 * {@link MicrosoftAuthService#prepareDownstreamLogin()} verifies at runtime.</p>
 *
 * <p>The test also deliberately avoids loading {@code EncryptionUtils} at all:
 * its static initializer fetches Mojang discovery data over the network, so
 * touching it would make this test fail in any offline environment. Key pairs
 * are generated locally (EC secp384r1, the same curve the library uses) and
 * the offline identity is built with {@link TestIdentityData}.</p>
 */
class MicrosoftAuthChainTest {

    private static KeyPair createKeyPair() throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("EC");
        gen.initialize(new ECGenParameterSpec("secp384r1"));
        return gen.generateKeyPair();
    }

    private static String base64(KeyPair pair) {
        return Base64.getEncoder().encodeToString(pair.getPublic().getEncoded());
    }

    private static String jwt(KeyPair signer, String x5u, Map<String, Object> claims) throws JoseException {
        long now = System.currentTimeMillis();
        JwtClaims jwtClaims = new JwtClaims();
        jwtClaims.setIssuedAt(NumericDate.fromMilliseconds(now));
        jwtClaims.setNotBefore(NumericDate.fromMilliseconds(now - TimeUnit.HOURS.toMillis(1)));
        jwtClaims.setExpirationTime(NumericDate.fromMilliseconds(now + TimeUnit.HOURS.toMillis(1)));
        claims.forEach(jwtClaims::setClaim);

        JsonWebSignature jws = new JsonWebSignature();
        jws.setPayload(jwtClaims.toJson());
        jws.setKey(signer.getPrivate());
        jws.setAlgorithmHeaderValue("ES384");
        jws.setHeader(HeaderParameterNames.X509_URL, x5u);
        return jws.getCompactSerialization();
    }

    private static Map<String, Object> payload(String token) throws JoseException {
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(token);
        return JsonUtil.parseJson(jws.getUnverifiedPayload());
    }

    private static String x5u(String token) throws JoseException {
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(token);
        return jws.getHeader(HeaderParameterNames.X509_URL);
    }

    private static void assertVerifies(String token, KeyPair key) throws JoseException {
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(token);
        jws.setKey(key.getPublic());
        assertTrue(jws.verifySignature(), "JWT signature should verify with the expected key");
    }

    @Test
    void downstreamChainHasThreeTokensInVanillaOrder() throws Exception {
        KeyPair sessionKey = createKeyPair();
        KeyPair mojangKey = createKeyPair();

        // Token 1 (Mojang): signed by Mojang, certifies the session public key.
        String mojangJwt = jwt(mojangKey, base64(mojangKey), Map.of(
                "iss", "Mojang",
                "identityPublicKey", base64(sessionKey)));
        // Token 2 (identity): carries the Xbox identity, verified via the key token 1 certifies.
        String identity = UUID.randomUUID().toString();
        String identityJwt = jwt(sessionKey, base64(sessionKey), Map.of(
                "iss", "Mojang",
                "identityPublicKey", base64(sessionKey),
                "extraData", Map.of("displayName", "TestPlayer", "XUID", "123456789", "identity", identity)));

        // Token 0: the self-signed token ProxyPass prepends, exactly like a vanilla client.
        String firstToken = ForgeryUtils.forgeIdentityToken(sessionKey, x5u(mojangJwt));

        List<String> chain = List.of(firstToken, mojangJwt, identityJwt);
        assertEquals(3, chain.size());

        // Walk the chain the way EncryptionUtils.validateChain does:
        // token 0 verifies with its own x5u (the session key) ...
        assertEquals(base64(sessionKey), x5u(firstToken));
        assertVerifies(firstToken, sessionKey);
        // ... and points at the Mojang key that signed token 1 ...
        assertEquals(base64(mojangKey), payload(firstToken).get("identityPublicKey"));
        assertEquals(Boolean.TRUE, payload(firstToken).get("certificateAuthority"));
        assertEquals(base64(mojangKey), x5u(mojangJwt));
        assertVerifies(mojangJwt, mojangKey);
        // ... token 1 certifies the session key that signed token 2 ...
        assertEquals(base64(sessionKey), payload(mojangJwt).get("identityPublicKey"));
        assertEquals(base64(sessionKey), x5u(identityJwt));
        assertVerifies(identityJwt, sessionKey);
        // ... and token 2 carries the identity the backend will see.
        @SuppressWarnings("unchecked")
        Map<String, Object> extraData = (Map<String, Object>) payload(identityJwt).get("extraData");
        assertEquals("TestPlayer", extraData.get("displayName"));
        assertEquals("123456789", extraData.get("XUID"));
        assertEquals(identity, extraData.get("identity"));

        // The forged skin token must also verify with the session key.
        String skin = ForgeryUtils.forgeSkinData(sessionKey, new org.jose4j.json.internal.json_simple.JSONObject(Map.of("SkinId", "test")));
        assertVerifies(skin, sessionKey);
    }

    @Test
    void forgeTokenStaysSelfSignedForOfflineMode() throws Exception {
        KeyPair keyPair = createKeyPair();
        var identity = TestIdentityData.offline("OfflinePlayer", "0");

        String token = ForgeryUtils.forgeToken(keyPair, identity);
        assertVerifies(token, keyPair);
        // Self-signed: the token certifies its own key, like the upstream
        // offline path always did - no Mojang signature involved.
        assertEquals(base64(keyPair), payload(token).get("cpk"));
        assertEquals(base64(keyPair), x5u(token));
        assertEquals("OfflinePlayer", payload(token).get("xname"));
        assertEquals("0", payload(token).get("xid"));
    }
}
