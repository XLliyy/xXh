package org.cloudburstmc.proxypass.auth;

import org.cloudburstmc.proxypass.Configuration;
import org.cloudburstmc.proxypass.ProxyPass;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class MicrosoftAuthConfigTest {

    private static String bundledConfig() throws Exception {
        try (var input = Objects.requireNonNull(
                ProxyPass.class.getClassLoader().getResourceAsStream("config.yml"), "config.yml")) {
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    @Test
    void microsoftAuthIsDisabledByDefault() throws Exception {
        Configuration configuration = Configuration.load(
                new ByteArrayInputStream(bundledConfig().getBytes(StandardCharsets.UTF_8)));
        assertNotNull(configuration.getMicrosoftAuth());
        assertFalse(configuration.getMicrosoftAuth().isEnabled());
        assertEquals("data/microsoft-auth.json", configuration.getMicrosoftAuth().getTokenFile());
        assertTrue(configuration.getMicrosoftAuth().isLoginOnStartup());
    }

    @Test
    void microsoftAuthCanBeEnabledViaConfig() throws Exception {
        String yaml = bundledConfig().replace("enabled: false", "enabled: true");
        Configuration configuration = Configuration.load(
                new ByteArrayInputStream(yaml.getBytes(StandardCharsets.UTF_8)));
        assertTrue(configuration.getMicrosoftAuth().isEnabled());
    }
}
