package org.cloudburstmc.protocol.bedrock.util;

import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Test helper that builds an {@code IdentityData} without calling
 * {@link EncryptionUtils#validateChain(java.util.List)}.
 *
 * <p>{@code IdentityData}'s constructor is private, so this uses reflection.
 * The indirection exists because loading {@code EncryptionUtils} fetches
 * Mojang discovery data over the network in its static initializer, which
 * makes any test that touches it unusable in offline environments even
 * though the code under test is fully offline. The full chain validation
 * (including the Mojang-root check) still runs at runtime in
 * {@code MicrosoftAuthService.prepareDownstreamLogin()}, where network is
 * available.</p>
 */
public final class TestIdentityData {

    private TestIdentityData() {
    }

    public static ChainValidationResult.IdentityData offline(String displayName, String xuid) {
        try {
            Constructor<ChainValidationResult.IdentityData> ctor = ChainValidationResult.IdentityData.class
                    .getDeclaredConstructor(String.class, UUID.class, String.class, String.class, String.class);
            ctor.setAccessible(true);
            return ctor.newInstance(
                    displayName,
                    UUID.nameUUIDFromBytes(("offline:" + displayName).getBytes(StandardCharsets.UTF_8)),
                    xuid,
                    null,
                    null);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Could not build test IdentityData", e);
        }
    }
}
