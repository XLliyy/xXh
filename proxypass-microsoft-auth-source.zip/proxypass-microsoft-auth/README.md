# ProxyPass

### Introduction

Proxy pass allows developers to MITM a vanilla client and server without modifying them. This allows for easy testing 
of the Bedrock Edition protocol and observing vanilla network behavior.

__ProxyPass requires  Java 8 u162 or later to function correctly due to the encryption used during login__<br>
`online-mode` __needs to be set to__ `false` __in__ `server.properties` __so that ProxyPass can communicate with your Bedrock Dedicated Server.__

### Building & Running
To produce a jar file, run `./gradlew shadowJar` in the project root directory. This will produce a jar file in the `build/libs` directory.

If you wish to run the project from source, run `./gradlew run` in the project root directory.

### Microsoft authentication (fork modification)

This copy adds optional Microsoft authentication for the downstream
connection, so the backend server may run with `online-mode=true`. See
[CARA-PAKAI.md](CARA-PAKAI.md) (Indonesian) for setup.

One honest limitation: a MITM proxy cannot forward the upstream player's own
Xbox identity (re-signing their chain would break the Mojang signature). The
proxy logs in once with a single Microsoft account of the operator
(device-code flow, `java -jar ProxyPass.jar --microsoft-login`), and every
player connecting through the proxy appears to the backend as that account's
gamertag/XUID. Offline mode (`microsoft-auth.enabled: false`, the default)
behaves exactly like upstream ProxyPass.

### Links

__[Jenkins](https://ci.opencollab.dev/job/NukkitX/job/ProxyPass/job/master/)__

__[Protocol library](https://github.com/CloudburstMC/Protocol) used in this project__
