# ProxyPass + Microsoft Auth — Cara Pakai

ProxyPass dari CloudburstMC yang dimodifikasi supaya bisa login ke Bedrock
Dedicated Server (BDS) dengan akun Microsoft asli, jadi backend boleh pakai
`online-mode=true`.

## Yang penting: batasan jujur

Proxy **tidak bisa** meneruskan identitas Xbox pemain yang connect lewat proxy.
Tanda tangan rantai Xbox pemain akan rusak kalau proxy menandatangani ulang
dengan kuncinya sendiri. Jadi cara kerjanya begini:

- Proxy login sendiri dengan **satu akun Microsoft milik operator** (device-code flow).
- Semua pemain yang connect lewat proxy akan terlihat di server sebagai
  **gamertag/XUID akun Microsoft itu**, bukan gamertag mereka sendiri.
- Kalau kamu cuma butuh proxy untuk dirimu sendiri / testing, ini sudah cukup.
  Kalau butuh tiap pemain tetap pakai identitasnya masing-masing, itu tidak
  bisa dilakukan oleh proxy MITM mana pun.

## Syarat

- Java 17 atau lebih baru (`java -version` untuk cek).
- Bedrock Dedicated Server (BDS) — boleh `online-mode=true` atau `false`.

## Langkah pakai (jar sudah jadi)

File `ProxyPass-MicrosoftAuth.jar` sudah dibuild dan siap jalan.

**1. Aktifkan Microsoft auth di `config.yml`:**

```yaml
microsoft-auth:
  enabled: true
  token-file: data/microsoft-auth.json
  login-on-startup: true
```

`config.yml` dibuat otomatis saat pertama kali jar dijalankan. Edit filenya,
lalu lanjut ke langkah 2.

**2. Login sekali dengan akun Microsoft:**

```bash
java -jar ProxyPass-MicrosoftAuth.jar --microsoft-login
```

Buka `microsoft.com/link` di browser, masukkan kode yang tampil di terminal,
lalu login dengan akun Microsoft kamu. Token tersimpan di
`data/microsoft-auth.json` dan dipakai ulang otomatis (refresh sendiri).

**3. Jalankan proxy seperti biasa:**

```bash
java -jar ProxyPass-MicrosoftAuth.jar
```

Default: proxy listen di `0.0.0.0:19122`, tujuan BDS di `127.0.0.1:19132`
(atur di `config.yml` bagian `proxy` dan `destination`).

**4. Di `server.properties` BDS, boleh pakai:**

```properties
online-mode=true
```

## Keamanan token

`data/microsoft-auth.json` berisi refresh token Microsoft kamu. **Jangan
dibagikan ke siapa pun** — siapa pun yang memegang file itu bisa login sebagai
akun Microsoft kamu di Minecraft. Kalau bocor, hapus file itu dan login ulang
langkah 2, lalu cabut akses aplikasi dari akun Microsoft kamu.

## Kalau ada masalah

| Gejala | Artinya |
|---|---|
| `Microsoft auth is enabled but no login is cached...` | Belum login — jalankan langkah 2. |
| `Microsoft login failed: ...` saat `--microsoft-login` | Cek internet / coba lagi; kode device-code kedaluwarsa setelah 15 menit. |
| Pemain di-kick saat join dengan pesan suruh login ulang | Refresh token mati (password diganti / akses dicabut) — jalankan langkah 2 lagi. |
| Proxy jalan tapi BDS menolak dengan `online-mode` | Pastikan langkah 2 sukses dan log menampilkan `Microsoft authentication enabled for downstream connections`. |

## Build ulang dari source

```bash
./gradlew shadowJar   # hasil di build/libs/
./gradlew test        # menjalankan test
```

Butuh Java 17 dan internet (Gradle mengunduh dependency).

## Yang sudah dites (dan yang belum)

Sudah dites di sini:

- Compile bersih (JDK 17) dan 4 unit test baru lolos: parsing config
  (default mati, bisa diaktifkan) dan konstruksi rantai login 3-token
  (urutan token + verifikasi tanda tangan ES384).
- Smoke test: mode offline (auth mati) bind listener di `0.0.0.0:19122` dan
  jalan; `--microsoft-login` dengan auth mati memberi peringatan bersih;
  boot dengan auth aktif tapi belum login gagal dengan pesan yang jelas.

Belum bisa dites di sini (butuh akun Microsoft + internet dari Java, yang
tidak tersedia di lingkungan ini):

- Login Microsoft asli (device-code flow) dan join BDS sungguhan dengan
  `online-mode=true`. Coba langkah 2–3 di mesin kamu dan kabari kalau ada
  error — log akan menunjukkan gamertag/XUID yang berhasil login.

Perubahan dari upstream ProxyPass: `src/main/java/org/cloudburstmc/proxypass/auth/MicrosoftAuthService.java`
(device-code login + pembangunan rantai downstream),
`network/bedrock/util/ForgeryUtils.java` (token identitas pertama),
`network/bedrock/session/UpstreamPacketHandler.java` (pakai login Microsoft
saat auth aktif), `ProxyPass.java` (mode `--microsoft-login`), dan
`src/main/resources/config.yml` (bagian `microsoft-auth`).
Library auth: RaphiMC MinecraftAuth 5.0.2.
